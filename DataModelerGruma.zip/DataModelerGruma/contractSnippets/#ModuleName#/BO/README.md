## In this subfolder we will host the contracts for Business Object (BO), List Objects (LO) and Lookup Objects (LU)
