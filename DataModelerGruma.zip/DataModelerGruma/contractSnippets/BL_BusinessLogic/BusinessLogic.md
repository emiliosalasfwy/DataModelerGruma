# Business Logic (BL) Contract Definition

## Description
The Business Logic Contract specifies a Method used by any of the Business Objects (BO, LO, LU) in the Mobility Application.